package com.raveneau.ppmt.algorithms;

public class TestGSP {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
